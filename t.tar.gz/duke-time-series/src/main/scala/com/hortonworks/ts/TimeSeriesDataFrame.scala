/*
 * Copyright (c) 2011-2018, Hortonworks Inc.  All rights reserved.
 * Except as expressly permitted in a written agreement between you
 * or your company and Hortonworks, Inc, any use, reproduction,
 * modification, redistribution, sharing, lending or other exploitation
 * of all or any part of the contents of this file is strictly prohibited.
 */

package com.hortonworks.ts

import breeze.interpolation.LinearInterpolator
import breeze.linalg.DenseVector
import org.apache.spark.sql.{Row, SQLContext, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable.ArrayBuffer
import java.sql.Timestamp
import java.util.Date

import org.apache.spark.sql.functions.unix_timestamp
import org.apache.spark.sql.types.{StructField, StructType, TimestampType,DoubleType, LongType}
/**
  * @author kan wang
  *
  * TimeSeriesDataFrame:
  *    Extends Spark DataFrame to provides following sets of operations on time-series data transformation and query functions.
  *    1) Up Sampling: transform a time-series dataframe at a higher sample rate
  *       with various interpolation algrothms.
  *
  *    2) Down Sampling: transform a time-series dataframe at a lower sample rate
  *                      with various aggregation algorithms
  *
  *    3) Weighted Moving Average
  *
  *    4) Transposition and Pivot
  *
  *    5) Lag/Led
  *
  *    6) Alignment (??)
  *
  *
  */
import org.apache.spark.sql.DataFrame
object ExtendDataFrame {
 implicit def timeSeriesDataFrame(dataFrame: DataFrame): TimeSeriesDataFrame =
  new TimeSeriesDataFrame(dataFrame: DataFrame)

  class TimeSeriesDataFrame(dataFrame: DataFrame) {


    /**
      * Up Sampling: transform a time-series dataframe at a higher sample rate with interpolation algroithms, Linear
      * Step, etc
      *
      * @param sampleIntervalPerSec
      * @param interoprType "Linear", "Step", etc
      * @return TimeSeriesDataFrame
      *
      */
  def upSampling(sampleIntervalPerSec: Long, interoprType: String): org.apache.spark.sql.DataFrame = {
    val interpolatorFunc = TimeSeriesInterpolator.interpType2InerpFunc(interoprType)
    upSampling(sampleIntervalPerSec, interpolatorFunc)
  }

    /**
      * Up Sampling: transform a time-series dataframe at a higher sample rate with interpolation algroithms, Linear
      * Step,etc
      * @param sampleIntervalPerSec
      * @param interpolatorFunc
      * @return TimeSeriesDataFrame
      */
  def upSampling(sampleIntervalPerSec: Long, interpolatorFunc: (Seq[Double], Seq[Double]) => Double => Double
             ): org.apache.spark.sql.DataFrame = {

    val arr_df = dataFrame.collect()

    val step = sampleIntervalPerSec * 1000
    // TODO: replacing hard code partition (10) with the configuraiton or argument
    val listOfSegements = arr_df.sliding(10, 9).toList
    val sc = dataFrame.sparkSession.sparkContext
    val g_step = sc.broadcast(step)
    //val rdd = sc.makeRDD(listOfPairs)
    val rdd = sc.parallelize(listOfSegements)
    //val r = rdd.map( pair => Helper_Func.func_interpolation(pair, g_step.value, Helper_Func.func_LinearInterpolator)).sortBy(_(0)).reduce(_++_)
    val r = rdd.map(pair => TimeSeriesInterpolator.func_Interpolation_Segment(pair, g_step.value, interpolatorFunc)).sortBy(_ (0)).reduce(_ ++ _)

    r match {
      case r if r(0)._1 != arr_df(0).get(1).asInstanceOf[Timestamp].getTime =>
        r.prepend(
          new Tuple2(arr_df(0).get(1).asInstanceOf[Timestamp].getTime, if (arr_df(0).get(2).isInstanceOf[Integer])
            arr_df(0).getInt(2).toDouble
          else
            arr_df(0).getDouble(2)))
      case _ => r
    }

    def dfSchema(columnNames: List[String]): StructType = {
      StructType(
        Seq(
          StructField(name = "time", dataType = LongType, nullable = false),
          StructField(name = "value", dataType = DoubleType, nullable = false)
        )
      )
    }

    val sqlContext = new SQLContext(sc)
    import sqlContext.implicits._
    sc.makeRDD(r).toDF("time", "value")

  }
  def dfSelect(tagColumn: String, timeColumn: String, dateFormat: String, valueColumn: String): DataFrame = {

      dataFrame.select(col(tagColumn), unix_timestamp(col(timeColumn), dateFormat).cast("timestamp").alias("time"),
        col(valueColumn)).filter(row => row.getString(0) != null)
  }
 }

}
