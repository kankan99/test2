/*
 * Copyright (c) 2011-2018, Hortonworks Inc.  All rights reserved.
 * Except as expressly permitted in a written agreement between you
 * or your company and Hortonworks, Inc, any use, reproduction,
 * modification, redistribution, sharing, lending or other exploitation
 * of all or any part of the contents of this file is strictly prohibited.
 */
package com.hortonworks.ts

import org.apache.spark.sql.{Row, SQLContext, SparkSession}
import org.apache.spark.sql.functions._

import java.sql.Timestamp
import java.util.Date

import com.hortonworks.ts.ExtendDataFrame.TimeSeriesDataFrame
import org.apache.spark.sql.functions.unix_timestamp
import org.apache.spark.sql.types.{DoubleType, LongType, StructField, StructType, TimestampType}
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import com.hortonworks.ts.ExtendDataFrame._
/**
  *
  * TimeSeriesUtils implements a set of convenient methods for time-series processing
  * @author Kan Wang
  */
import org.apache.spark.sql.DataFrame

object TimesSeriesUtils {

  def createSparkSession(sourceFile:String) : (SparkSession, String) = {
    val spark = SparkSession.builder().
      config("spark.sql.warehouse.dir", "/apps/hive/warehouse").
      config("hive.metastore.uris", "thrift://sandbox-hdp.hortonworks.com:9083").
      enableHiveSupport().
      getOrCreate()

    spark.sparkContext.hadoopConfiguration.set("dfs.client.use.datanode.hostname", "true")
    spark.sparkContext.setLogLevel("ERROR")
    Tuple2(spark,  sourceFile)
  }

  def csv2df(spark: SparkSession, csvFilePath: String): DataFrame = {

    spark.read.format("com.databricks.spark.csv")
      .option("header", "true")
      .option("delimiter", ",")
      .option("inferSchema", "true")
      .load(csvFilePath)

  }

  def orc2df(spark: SparkSession, orcFilePath: String): DataFrame = {
    spark.sql("SET spark.sql.orc.enabled=true")
    spark.read.format("org.apache.spark.sql.execution.datasources.orc").load(orcFilePath)
  }

  def csv2orc(spark: SparkSession, csvFilePath: String, orcFilePath: String): Unit = {
    val df = csv2df(spark, csvFilePath)

    df.write.format("orc").mode("overwrite").save(orcFilePath)
  }

  def dfSelect(df: DataFrame, tagColumn: String, timeColumn: String, dateFormat: String, valueColumn: String): DataFrame = {

    df.select(col(tagColumn), unix_timestamp(col(timeColumn), dateFormat).cast("timestamp").alias("time"),
      col(valueColumn)).filter(row => row.getString(0) != null)
  }

  val Minute_MillSecond = 60000

  def round2Minute(date: Date): Date = {
    val x = date.getTime()
    new Date(round2Minute(x))
  }

  def round2Minute(epicTime: Long) = {
    epicTime - epicTime % Minute_MillSecond
  }

  def interval_bound(observated: Date, step_size_in_sec: Long): Date = {
    val x = observated.getTime()
    new Date(interval_bound(x, step_size_in_sec))
  }

  def interval_bound(o_epicTime: Long, step_size_in_sec: Long) = {
    o_epicTime - o_epicTime % (step_size_in_sec * 1000)
  }

  def interval_bound_func(step_size_in_sec:Long): (Long) => (Long) = {
    (o_epicTime: Long) => o_epicTime - o_epicTime % (step_size_in_sec * 1000)
  }

  def upSamplingInterpolation(df : DataFrame, interOpType : String, sampleInterval: Int, dateFormat:String): DataFrame ={

    val df1 = df.dfSelect("Compressed", "time", dateFormat, "value")

    df1.printSchema()
    df1.show

    val df2 = df.dfSelect("Sampled", "Sampled_time",  "mm/dd/yy HH:mm", "Sampled_value")
    df2.printSchema()
    df2.show
    //val interpRs = new InterpolationSampling().upDist(60, "Linear", df1 )
    val interpRs = df1.upSampling(sampleInterval, interOpType)
    // val interpRs_r = interpRs.withColumn("timeSlice", timeSlice)

    val c =(interpRs("time")/1000).cast(TimestampType)

    val interpRs_df = interpRs.withColumn("time", c)
    interpRs_df.join(df2, "time")
  }

}
