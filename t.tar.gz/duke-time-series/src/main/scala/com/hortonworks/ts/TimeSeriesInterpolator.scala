/*
 * Copyright (c) 2011-2018, Hortonworks Inc.  All rights reserved.
 * Except as expressly permitted in a written agreement between you
 * or your company and Hortonworks, Inc, any use, reproduction,
 * modification, redistribution, sharing, lending or other exploitation
 * of all or any part of the contents of this file is strictly prohibited.
 */
package com.hortonworks.ts

import breeze.interpolation.LinearInterpolator
import breeze.linalg.DenseVector
import org.apache.spark.sql.{Row, SQLContext, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable.ArrayBuffer
import java.sql.Timestamp
import java.util.Date

import org.apache.spark.sql.functions.unix_timestamp
import org.apache.spark.sql.types.{StructField, StructType, TimestampType,DoubleType, LongType}
/**
  *
  * TimeSeriesInterpolator: implements generic interpolator, "Linear", "Step", TimeStamping mapping to Time Slice, etc
  * @author Kan Wang
  */

object TimeSeriesInterpolator extends Serializable {


  def func_Interpolation_Segment(list: Array[Row], step: Long, interpolation: (Seq[Double], Seq[Double]) => Double => Double): ArrayBuffer[Tuple2[Long, Double]] = {
    val result = collection.mutable.ArrayBuffer[Tuple2[Long,Double]]()
    val listOfPairs = list.sliding(2, 1).toList
    listOfPairs.foreach { pair => result ++=func_interpolation(pair, step, interpolation) }
    result
  }
  def func_interpolation(pair: Array[Row], step: Long, interpolation: (Seq[Double], Seq[Double]) => Double => Double): ArrayBuffer[Tuple2[Long, Double]] = {
    var xList = collection.mutable.ArrayBuffer[Double]()
    val t1 = pair(0).get(1).asInstanceOf[Timestamp].getTime.toDouble
    val t2 = pair(1).get(1).asInstanceOf[Timestamp].getTime.toDouble
    val timeDelta = t2 - t1
    var dp = (TimesSeriesUtils.round2Minute(t1.toLong)).toDouble
    val additionalXValues = (timeDelta / step).toInt

    additionalXValues match {
      case steps if timeDelta <= step => xList = xList :+ t1 :+ t2
      case _ =>
        for (newV <- 0 until additionalXValues) {
          dp += step
          xList = xList :+ dp
        }
        if (additionalXValues < timeDelta /step) xList = xList :+ t2
    }
    val r1 = xList.map { x => (x.toLong.toDouble) }
    val x = pair.map(row => row.get(1).asInstanceOf[Timestamp].getTime.toDouble)

    val y = pair.map(row =>
      if (row.get(2).isInstanceOf[Integer]) row.getInt(2) else row.getDouble(2))
    //val y = pair.map(row => row.getDouble(2))
    val f = interpolation(x, y)
    val s1yValues = xList.map { case (x) => f(x) }
    r1.map { x => x.toLong } zip s1yValues
  }

  def func_LinearInterpolator(xx: Seq[Double], yy: Seq[Double]) = {
    val x = DenseVector(xx: _*)
    val y = DenseVector(yy: _*)
    val f = LinearInterpolator(x, y)
    (w: Double) => {
      w match {
        case t if t >= x(0) && t <= x(1) => f(t)
        case _ => throw new IllegalArgumentException("x value " + w + " is outbound of (" + x(0) + "," + x(1) + ")")
      }
    }
  }

  def func_StepInterpolator(xPair: Seq[Double], yPair: Seq[Double]) = {
    (w: Double) => {
      val x1 = xPair(0)
      val x2 = xPair(1)
      val y1 = yPair(0)
      val y2 = yPair(1)

      w match {
        case t if t > x1 && t < x2 => y1
        case t if t >= x2 => y2
        case t if t == x1 => y1
        case _ => throw new IllegalArgumentException("x value " + w + " is outbound of (" + x1 + "," + x2 + ")")
      }
    }
  }

  def interpType2InerpFunc(interpType: String): (Seq[Double], Seq[Double]) => Double => Double = {
    interpType match {
      case "Linear" => TimeSeriesInterpolator.func_LinearInterpolator
      case "Step" => TimeSeriesInterpolator.func_StepInterpolator
      case _ => throw new IllegalArgumentException("interpType " + interpType + " is not supported" + " supported type: Linear, Step")
    }
  }

}
