/*
 * Copyright (c) 2011-2018, Hortonworks Inc.  All rights reserved.
 * Except as expressly permitted in a written agreement between you
 * or your company and Hortonworks, Inc, any use, reproduction,
 * modification, redistribution, sharing, lending or other exploitation
 * of all or any part of the contents of this file is strictly prohibited.
 */
package com.hortonworks.ts

import java.sql.Timestamp

import breeze.interpolation.LinearInterpolator
import breeze.linalg.DenseVector
import org.apache.spark.sql.Row

import scala.collection.mutable.ArrayBuffer

/**
  *
  * TimeSeriesAggregator: implements generic Aggregator, "Avg", "Max","Min", "Median", "Middle", "Last","Sum"
  * TimeStamping mapping to Time Slice, etc
  * @author Kan Wang
  */
import org.apache.spark.sql._
object TimeSeriesAggregator extends Serializable {
  def func_avg(df : DataFrame) = {
     (rate : Long) =>  {
        df
      }


  }

  def func_Last(df : DataFrame) = {
    (rate : Long) =>  {
      df

    }

  }

  def func_Max(df : DataFrame) = {
     (rate : Long) =>  {
       df

    }

  }

  def interpType2AggregatorFunc(interpType: String): (DataFrame) => Long => DataFrame = {
    interpType match {
      case "Avg" => TimeSeriesAggregator.func_avg
      case "Max" => TimeSeriesAggregator.func_Max
      case _ => throw new IllegalArgumentException("interpType " + interpType + " is not supported" + " supported type: Linear, Step")
    }
  }


}
