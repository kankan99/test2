/*
 * Copyright (c) 2011-2018, Hortonworks Inc.  All rights reserved.
 * Except as expressly permitted in a written agreement between you
 * or your company and Hortonworks, Inc, any use, reproduction,
 * modification, redistribution, sharing, lending or other exploitation
 * of all or any part of the contents of this file is strictly prohibited.
 */
package com.hortonworks.ts

import java.text.SimpleDateFormat

import org.junit.{Assert, Before, Test}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import com.hortonworks.ts.ExtendDataFrame._
import org.apache.spark.sql.hive._
/**
  * @author K.Wang
  */


class TimeSeriesDataFrameTest   {

  def createSparkSession(sourceFile:String) : (SparkSession, String) = {
    val spark = SparkSession.builder().master("local").appName("Scythe cvs2").
      config("spark.sql.warehouse.dir", "/apps/hive/warehouse").
      config("hive.metastore.uris", "thrift://localhost:9083").
     enableHiveSupport().
     getOrCreate()

    spark.sparkContext.hadoopConfiguration.set("dfs.client.use.datanode.hostname", "true")
    spark.sparkContext.setLogLevel("ERROR")
    Tuple2(spark, getClass.getResource("/" + sourceFile).toString())
  }

  @Before def initialize() {
    println("Dataset Tests")
  }

  private val datef = new SimpleDateFormat("mm/dd/yy HH:mm")
  private val d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

  @Test def testUpSampling_LI_fromCSV(): Unit = {
    val (spark, path) = createSparkSession("horton_works_pi_data_examples2.csv")
    val df = TimesSeriesUtils.csv2df(spark,path)
    //val testDf = testUpSamplingInterpolation(df, "Linear","mm/dd/yy HH:mm")
    val testDf = TimesSeriesUtils.upSamplingInterpolation(df, "Linear",60, "mm/dd/yy HH:mm")
    testDf.show(200)
    testDf.collect().map{ x => Assert.assertEquals( x.getDouble(3), x.getDouble(1), 0.0001)}
    df.write.format("orc").mode("overwrite").saveAsTable("SourceInterOperLinear")
    testDf.write.format("orc").mode("overwrite").saveAsTable("InterOperLinear")
    testDf.write.format("csv").mode("overwrite").save("/tmp/LinearSamplingResult.csv")
  }

  @Test def testUpSampling_LI_fromORC(): Unit = {

    val (spark, path) = createSparkSession("horton_works_pi_data_examples2_orc")
    val df = TimesSeriesUtils.orc2df(spark,path)
    val testDf = testUpSamplingInterpolation(df, "Linear","mm/dd/yy HH:mm")
    testDf.show(200)
    testDf.collect().map{ x => Assert.assertEquals( x.getDouble(3), x.getDouble(1), 0.0001)}
  }

  @Test def testUpSampling_SI_fromCSV() {
    val (spark, path) = createSparkSession("horton_works_pi_data_tap.csv")
    val df = TimesSeriesUtils.csv2df(spark, path)
   // val testDf = testUpSamplingStepInterpolation(df, "Step")
    val testDf = testUpSamplingInterpolation(df,"Step","mm/dd/yy HH:mm:ss")
    df.show(200)
    testDf.collect().map{ x => Assert.assertEquals( x.getInt(3).toDouble, x.getDouble(1), 0.0)}
    df.write.format("orc").mode("overwrite").saveAsTable("SourceStep")
    testDf.write.format("orc").mode("overwrite").saveAsTable("InterOpStep")
  }

  @Test def testUpSampling_SI_fromORC() {
    val (spark, path) = createSparkSession("orc_org_step")
    val df = TimesSeriesUtils.orc2df(spark, path)
    val testDf = testUpSamplingInterpolation(df,"Step", "mm/dd/yy HH:mm:ss")
    df.show(200)
    testDf.collect().map{ x => Assert.assertEquals( x.getInt(3).toDouble, x.getDouble(1), 0.0)}
  }

  @Test def testUpSampling_SI_fromTable(): Unit = {
    val (spark, path) = createSparkSession("orc_org_step")
    val df = spark.sql("select * from sourcestep")
    val testDf = testUpSamplingInterpolation(df,"Step","mm/dd/yy HH:mm:ss")
    testDf.collect().map{ x => Assert.assertEquals( x.getInt(3).toDouble, x.getDouble(1), 0.0)}
  }

  def testUpSamplingInterpolation(df : DataFrame, interOpType : String, dateFormat:String): DataFrame ={

    val df1 = df.dfSelect("Compressed", "time",dateFormat, "value")

    df1.printSchema()
    df1.show

    val df2 = df.dfSelect("Sampled", "Sampled_time",  "mm/dd/yy HH:mm", "Sampled_value")
    df2.printSchema()
    df2.show
    //val interpRs = new InterpolationSampling().upDist(60, "Linear", df1 )
    val interpRs = df1.upSampling(60, interOpType)
    // val interpRs_r = interpRs.withColumn("timeSlice", timeSlice)

    val c =(interpRs("time")/1000).cast(TimestampType)
    //val c1 = (interpRs("time")) - (interpRs("time")%(300*1000))
    // val c1 = udf(TimesSeriesUtils.interval_bound_func(300*1000)).apply(interpRs("time"))

    val interpRs_df = interpRs.withColumn("time", c)
    // val interpRs_df2 = interpRs_df.withColumn("timeSlice", c1)
    // interpRs_df2.show

    interpRs_df.join(df2, "time")
    /*
    // val testDf = interpRs_df.join(df2, "time")
    // testDf.show(200)
    //val result = testDf.collect()
    // result.map{ x => Assert.assertEquals( x.getInt(3).toDouble, x.getDouble(1), 0.0)}
    // testDf.collect().map{ x => Assert.assertEquals( x.getDouble(3), x.getDouble(1), 0.0001)}

    val interpRs_arr = interpRs.collect()
    val arr_df = df2.collect()
    println("Staring Sampling with Linear Interpolation and validating the result")
    // val interpRs_d = interpRs_arr.map(x => (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(x._1)), x._2))
    val interpRs_d = interpRs_arr.map(x => (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(x.getLong(0))), x.getDouble(1)))
    interpRs_d.foreach { println }
    (interpRs_d zip arr_df).filter(x=> x._1 != Nil).map(y=> Assert.assertEquals(y._1._2, y._2.getDouble(2), 0.0001))
    println("Completing Sampling with Linear Interpolation")
    */

  }

  def testUpSamplingStepInterpolation(df : DataFrame, interOpType:String):DataFrame = {
    //  val (spark, path) = createSparkSession("horton_works_pi_data_tap.csv")
    //  val df =  TimesSeriesUtils.csv2df(spark,path)
    //  val (spark, path) = createSparkSession("orc_org_step")
    //  val df = TimesSeriesUtils.orc2df(spark,path)
    //  val df = spark.read.format("org.apache.spark.sql.execution.datasources.orc").load(path)

    val df1 = df.dfSelect("Compressed", "time","mm/dd/yy HH:mm:ss", "value")
    df1.printSchema()
    df1.show(50)

    val df2 = df.dfSelect("Sampled","Sampled_time", "mm/dd/yy HH:mm", "Sampled_value")
    df2.printSchema()
    df2.show(50)
    val interpRs = df1.upSampling(60, interOpType)
    //interpRs.map(x => new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(x.getLong(0)), x.getDouble(1)))

    // val timeSlice = from_unixtime((interpRs("time")/1000),"yyyy-MM-dd HH:mm:ss")


    // val interpRs_r = interpRs.withColumn("timeSlice", timeSlice)

    val c =(interpRs("time")/1000).cast(TimestampType)

    val interpRs_df = interpRs.withColumn("time", c)
    // interpRs_df.printSchema()
    // interpRs_r.printSchema()
    // interpRs_df.show(50)

    interpRs_df.join(df2, "time")
    // testDf.write.format("orc").mode("overwrite").save("/tmp/orc_100m")
    // testDf.write.format("csv").mode("overwrite").save("/tmp/csv_step")
    /*
    df.show(200)
    //val result = testDf.collect()
    // result.map{ x => Assert.assertEquals( x.getInt(3).toDouble, x.getDouble(1), 0.0)}

    // testDf.write.format("orc").mode("overwrite").saveAsTable("SourceStep")
    // testDf.write.format("orc").mode("overwrite").saveAsTable("InterOpStep")
    testDf.collect().map{ x => Assert.assertEquals( x.getInt(3).toDouble, x.getDouble(1), 0.0)}
    // df.write.format("orc").mode("append").insertInto("Step")
    */
  }

}

object TimeSeriesMain {
  def main (args: Array[String] ): Unit = {
  val spark = SparkSession.builder
              .master ("local")
              .appName ("spark sesson example")
           //   .config ("spark.sql.warehouse.dir", "/app/hive/warehouse")
           //   .config ("hive.metastor.uris", "thrift://localhost:9083")
              .enableHiveSupport ()
              .getOrCreate ()

   val df = spark.sql("select * from Step")
   df.show

   }
}