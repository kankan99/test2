/*
 * Copyright (c) 2011-2018, Hortonworks Inc.  All rights reserved.
 * Except as expressly permitted in a written agreement between you
 * or your company and Hortonworks, Inc, any use, reproduction,
 * modification, redistribution, sharing, lending or other exploitation
 * of all or any part of the contents of this file is strictly prohibited.
 */
package com.hortonworks.ts

import java.text.SimpleDateFormat

import com.hortonworks.ts.ExtendDataFrame._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.junit.{Assert, Before, Test}
import java.sql.Timestamp
import java.util.Date

import scala.collection.mutable.ArrayBuffer

/**
  * @author K.Wang
  */

import org.apache.spark.sql.{Row, SQLContext, SparkSession}

class TimeSeriesInterpolatorTest   {

  private val d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

  private val Expected = Array(1.0,1.8,2.6,3.4,4.2,5.0,5.6, 6.2,6.8,7.4,8.0)

  @Before def initialize() {
    println("Dataset Tests")
  }


  @Test def testLinearInterpolator: Unit = {
    val signals = Array(
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:00:00"), 1.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:05:00"), 5.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:10:00"), 8.0))
       var interpolationValues =
       TimeSeriesInterpolator.func_Interpolation_Segment(signals,
                                                          60000, TimeSeriesInterpolator.interpType2InerpFunc("Linear"))

    if (interpolationValues(0)._1 != (signals(0).get(1).asInstanceOf[Timestamp].getTime))
      interpolationValues.prepend(Tuple2(signals(0).get(1).asInstanceOf[Timestamp].getTime, signals(0).getDouble(2)))
    (interpolationValues zip Expected).map{ x => Assert.assertEquals(x._1._2, x._2,0)}
  }

  @Test def testStepInterpolator: Unit = {
    val signal2 = Array(
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:01:00"), 2.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:02:00"), 6.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:05:00"), 3.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:07:00"), 5.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:10:00"), 9.0)
    )

    val expectedStepResult = Array(
      2.0,6.0,6.0,6.0,3.0,3.0,5.0,5.0,5.0,9.0
    )
    val arr =
      TimeSeriesInterpolator.func_Interpolation_Segment(signal2,
        60000, TimeSeriesInterpolator.interpType2InerpFunc("Step"))

    if (arr(0)._1 != (signal2(0).get(1).asInstanceOf[Timestamp].getTime))
       arr.prepend(Tuple2(signal2(0).get(1).asInstanceOf[Timestamp].getTime, signal2(0).getDouble(2)))

    arr. foreach { x => println(x) }
    (arr zip expectedStepResult).map{ x => Assert.assertEquals(x._1._2, x._2,0)}
  }

  @Test def testStepInterpolator_2: Unit = {
    val signal2 = Array(
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:01:00"), 2.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:01:01"), 3.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:03:00"), 6.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:08:00"), 3.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:11:00"), 5.0),
      Row.fromTuple("s1",java.sql.Timestamp.valueOf("2018-04-01 8:13:00"), 9.0)
    )

    val expectedStepResult = Array(
      2.0,3.0,3.0, 6.0,6.0,6.0,6.0,6.0,3.0, 3.0,3.0,5.0,5.0,9.0
    )
    val arr =
      TimeSeriesInterpolator.func_Interpolation_Segment(signal2,
        60000, TimeSeriesInterpolator.interpType2InerpFunc("Step"))

    if (arr(0)._1 != (signal2(0).get(1).asInstanceOf[Timestamp].getTime))
      arr.prepend(Tuple2(signal2(0).get(1).asInstanceOf[Timestamp].getTime, signal2(0).getDouble(2)))

    arr. foreach { x => println( (new Date(x._1), x._2)) }
    (arr zip expectedStepResult).map{ x => Assert.assertEquals(x._1._2, x._2,0)}
  }

  private val datef = new SimpleDateFormat("mm/dd/yy HH:mm")

}
