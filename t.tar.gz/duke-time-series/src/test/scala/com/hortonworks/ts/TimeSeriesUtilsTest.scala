/*
 * Copyright (c) 2011-2018, Hortonworks Inc.  All rights reserved.
 * Except as expressly permitted in a written agreement between you
 * or your company and Hortonworks, Inc, any use, reproduction,
 * modification, redistribution, sharing, lending or other exploitation
 * of all or any part of the contents of this file is strictly prohibited.
 */
package com.hortonworks.ts

import java.text.SimpleDateFormat

import com.hortonworks.ts.ExtendDataFrame._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.junit.{Assert, Before, Test}

/**
  * @author K.Wang
  */


class TimeSeriesUtilsTest   {

  @Before def initialize() {
    println("TimerSeriesUtils Tests")
  }

  def createSparkSession(csvFile:String) : (SparkSession, String) = {
    val spark = SparkSession.builder().master("local").appName("Scythe cvs3").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    Tuple2(spark, getClass.getResource("/" + csvFile).toString())
  }


  @Test def testIntervalBound_step_30_1() = {
    val timeSlot1 = TimesSeriesUtils.interval_bound(d.parse("2018-04-01 12:00:31"), 30)
    Assert.assertEquals(timeSlot1, d.parse("2018-04-01 12:00:30"))
  }

  @Test def testIntervalBound_step_30_2() = {
    val timeSlot1 = TimesSeriesUtils.interval_bound(d.parse("2018-04-01 11:59:31"), 30)
    Assert.assertEquals(timeSlot1, d.parse("2018-04-01 11:59:30"))
  }

  @Test def testIntervalBound_step_30_3() = {
    val timeSlot1 = TimesSeriesUtils.interval_bound(d.parse("2018-04-01 11:59:29"), 30)
    Assert.assertEquals(timeSlot1, d.parse("2018-04-01 11:59:00"))
  }

  @Test def testIntervalBound_step60_1() = {
    val timeSlot1 = TimesSeriesUtils.interval_bound(d.parse("2018-04-01 11:59:29"), 60)
    Assert.assertEquals(timeSlot1, d.parse("2018-04-01 11:59:00"))
  }

  @Test def testIntervalBound_step60_2() = {
    val timeSlot1 = TimesSeriesUtils.interval_bound(d.parse("2018-04-01 11:59:31"), 60)
    Assert.assertEquals(timeSlot1, d.parse("2018-04-01 11:59:00"))
  }

  @Test def testDFSelect() {
    val (spark, path) = createSparkSession("horton_works_pi_data_examples.csv")
    val df=TimesSeriesUtils.csv2df(spark, path)
    val selectedDF =  df.dfSelect( "Compressed", "time", "mm/dd/yy HH:mm","value")
    selectedDF.show
    val selectedDF2 = df.dfSelect("Sampled", "Sampled_time", "mm/dd/yy HH:mm", "Sampled_value")

    selectedDF2.show
  }

  @Test def loadCsvTest() = {
    val (spark, path) = createSparkSession("horton_works_pi_data_examples.csv")
    val df = TimesSeriesUtils.csv2df(spark, path)
    df.show
  }

  @Test def loadOrcTest() = {
    val (spark, path) = createSparkSession("orc_org_step")
    val df = TimesSeriesUtils.orc2df(spark,path)
    df.show(100)

  }

  @Test def loadOrcLinearTest() = {
    val (spark, path) = createSparkSession("horton_works_pi_data_examples2_orc")
    val df = TimesSeriesUtils.orc2df(spark,path)
    df.show(1440)
  }

  @Test def csv2orcTest = {
    val (spark, path) = createSparkSession("horton_works_pi_data_examples2.csv")
    // val orcPath = getClass.getResource("/" ).toString() + "/horton_works_pi_data_examples2_orc"
    val orcPath = "src/test/resources/" + "horton_works_pi_data_examples2_orc"
    TimesSeriesUtils.csv2orc(spark, path, orcPath)
  }

  private val datef = new SimpleDateFormat("mm/dd/yy HH:mm")
  private val d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

}
